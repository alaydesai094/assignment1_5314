//
//  ViewController.swift
//  APIDemo
//
//  Created by Parrot on 2019-03-03.
//  Copyright © 2019 Parrot. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import WatchConnectivity
import MapKit


class ViewController: UIViewController, WCSessionDelegate, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var m1: UILabel!
    @IBOutlet weak var m2: UILabel!
    @IBOutlet weak var m3: UILabel!
    @IBOutlet weak var m4: UILabel!
    
    
    
    
    @IBOutlet weak var s1: UILabel!
    
    @IBOutlet weak var s2: UILabel!
    
  
    
    
    @IBOutlet weak var tp: UILabel!
    
    
    
    @IBOutlet weak var fnls: UILabel!
    
    
    
    
    
    var list = [
        "pritesh",
        "patel",
        "p@gmail.com",
        "45.0",
        "-234.2",
        "ppatel",
        "1234"
    ]
    
   
    var qtrArray: [String] = []
    var semiArray : [String] = []
    var fnlArray : [String] = []
    var tpArray : [String] = []

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       print(self.qtrArray.count)
        return(self.qtrArray.count)
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        print(self.qtrArray)
        let myRow = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "myRow")
        myRow.textLabel?.text = self.qtrArray[indexPath.row]
        
        
        
        return(myRow)
    }
    
    
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?)
    {
        
    }
    
    func sessionDidBecomeInactive(_ session: WCSession)
    {
        
    }
    
    func sessionDidDeactivate(_ session: WCSession)
    {
        
    }
    

    
    // MARK: Outlets
    @IBOutlet weak var outputLabel: UILabel!
    
    @IBOutlet weak var mapView: MKMapView!
    
    // MARK: Default functions
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let URL = "https://fifaassignment.firebaseio.com/Staduim.json"
        let URLfnl = "https://fifaassignment.firebaseio.com/Finals.json"
         let URLqtr = "https://fifaassignment.firebaseio.com/Quarterfinal.json"
         let URLsemi = "https://fifaassignment.firebaseio.com/Semifinal.json"
         let URLtp = "https://fifaassignment.firebaseio.com/Thirdplace.json"
       
        Alamofire.request(URL).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let apiData = response.result.value
            if (apiData == nil) {
                print("Error when getting API data")
                return
            }
            // -- if no errors, then keep going
            //print(apiData)
            
            // 2a. Convert the response to a JSON object
            //var jsonResponse = JSON(apiData)
            
//          //  print(jsonResponse)
//
//            if (self.mapView.delegate = self as? MKMapViewDelegate) != nil {
//
//            // item #3 = position 2
//            for (name ,value) in jsonResponse {
//                //print(name , value)
//                let lat = value["lat"]
//                 let long = value["long"]
//                let pin = MKPointAnnotation()
//
//                print(lat,long)
//
//                // set the center of the map
//                let x = CLLocationCoordinate2DMake(lat.double! , long.double!)
//
//                // pick a zoom level
//                let y = MKCoordinateSpanMake(2.0, 2.0)
//                // set the region property of the mapview
//                let z = MKCoordinateRegionMake(x, y)
//               self.mapView.setRegion(z, animated: true)
//                pin.coordinate = x
//                // 4. Show the pin on the map
//              self.mapView.addAnnotation(pin)
//            }
//            }
//            else {
//                print("MapKit Empty/wasn’t set successfully")
//            }
       
            
        }
        
        Alamofire.request(URLfnl).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let FinalsData = response.result.value
            if (FinalsData == nil) {
                print("Error when getting API data")
                return
            }
            // -- if no errors, then keep going
            //print(apiData)
            
            // 2a. Convert the response to a JSON object
            var jsonResponseFnl = JSON(FinalsData!)
            
             let fnl = jsonResponseFnl["finalmatch"].stringValue
          
            
            print(fnl)
            
            self.m1.text = fnl
        
            //print(jsonResponseFnl)
            
//            for (name) in (jsonResponseFnl){
//
//                let fnl = jsonResponseFnl["finalmatch"].stringValue
//
//                self.fnlArray.append(fnl)
//                print(self.fnlArray)
//
//
//            }

            
        }
        
        
        Alamofire.request(URLqtr).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let QtrData = response.result.value
            if (QtrData == nil) {
                print("Error when getting API data")
                return
            }
            // -- if no errors, then keep going
            //print(apiData)
            
            // 2a. Convert the response to a JSON object
            var jsonResponseqtr = JSON(QtrData!)
            
            print(jsonResponseqtr)
            
//            let m1 = jsonResponseqtr["Match1"].stringValue
//            self.m1.text = m1
//
//            let m2 = jsonResponseqtr["Match2"].stringValue
//            self.m2.text = m2
//
//            let m3 = jsonResponseqtr["Match3"].stringValue
//            self.m3.text = m3
//
//            let m4 = jsonResponseqtr["Match4"].stringValue
//            self.m4.text = m4
            
            
            for (name,value) in (jsonResponseqtr){

                let fnl = value["Team"].stringValue

                self.qtrArray.append(fnl)
                print(self.qtrArray)


            }
            
            self.m1.text = self.qtrArray[0]
            self.m2.text = self.qtrArray[1]
            self.m3.text = self.qtrArray[2]
            self.m4.text = self.qtrArray[3]
            
            
            
        }
        
        Alamofire.request(URLsemi).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let semiData = response.result.value
            if (semiData == nil) {
                print("Error when getting API data")
                return
            }
            // -- if no errors, then keep going
            //print(apiData)
            
            // 2a. Convert the response to a JSON object
            var jsonResponseSemi = JSON(semiData!)
            
            print(jsonResponseSemi)
            
            for (name,value) in (jsonResponseSemi){
                
                let fnl = value["Team"].stringValue
                
                self.qtrArray.append(fnl)
                print(self.qtrArray)
                
                
            }
            
        }
        
        Alamofire.request(URLtp).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let tpData = response.result.value
            if (tpData == nil) {
                print("Error when getting API data")
                return
            }
            // -- if no errors, then keep going
            //print(apiData)
            
            // 2a. Convert the response to a JSON object
            var jsonResponsetp = JSON(tpData!)
            
            print(jsonResponsetp)
            
            for (name,value) in (jsonResponsetp){
                
                let fnl = value["Team"].stringValue
                
                self.qtrArray.append(fnl)
                print(self.qtrArray)
                
                
            }
            
        }
    
        
        
        
        
        
        
        
       
        
        
        
        
        
        
        
        
    
        // Does your iPhone support "talking to a watch"?
        // If yes, then create the session
        // If no, then output error message
        if (WCSession.isSupported()) {
            print("PHONE: Phone supports WatchConnectivity!")
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
        else {
            print("PHONE: Phone does not support WatchConnectivity")
        }
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    // MARK: Actions
    
    @IBAction func buttonPressed(_ sender: Any) {
        print("button pressed")
        
        // check if the watch is paired / accessible
        if (WCSession.default.isReachable) {
            // construct the message you want to send
            // the message is in dictionary
            let abc = [
                "message":"\(self.qtrArray[0])",
               
            ]
            // send the message to the watch
            WCSession.default.sendMessage(abc, replyHandler: nil)
        }
        else
        {
            print("PHONE: Cannot find the watch")
        }
        
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView)
    {
        print("annotation is clicked")
        
        //        let vc1 = self.storyboard?.instantiateViewController(withIdentifier: "show")
        //        self.navigationController?.pushViewController(vc1!, animated: true)
        
    }
    
}

