//
//  MapViewController.swift
//  APIDemo
//
//  Created by Dhyanee Bhatt on 2019-06-27.
//  Copyright © 2019 Parrot. All rights reserved.
//

import WatchKit

class MapViewController: NSObject {

     @IBOutlet weak var mapView: MKMapView!
}
