//
//  Page1InterfaceController.swift
//  APIDemo WatchKit Extension
//
//  Created by MacStudent on 2019-06-26.
//  Copyright © 2019 Parrot. All rights reserved.
//

import WatchKit
import Foundation
import Alamofire
import SwiftyJSON
import WatchConnectivity

class Page1InterfaceController: WKInterfaceController, WCSessionDelegate {
    
    
    var qtrArray: [String] = []
    var semiArray : [String] = []
    var fnlArray : [String] = []
    var tpArray : [String] = []
    
    
    // MARK: Required function for WCSessionDelegate
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        
        // output a debug message to the terminal
        print("WATCH: Got a message!")
        print(message)
        /*
         
         message = {
         "lastname":"cat",
         "firstname":"blue"
         "email":
         "lat":
         "lng"
         "username":
         "password":
         }
         */
//        self.personDataList = [
//            message["item"] as! String
//        ]
//
//        // 1. Tell watch how many rows you want
//        self.tableViewThing.setNumberOfRows(
//            self.personDataList.count, withRowType:"myRow"
//        )
//
//        // 2. Tell watch what data goes in each row
//        for (index, data) in self.personDataList.enumerated() {
//            let row = self.tableViewThing.rowController(at: index) as! RowController
//            row.outputLabel.setText(data)
//        }
//
        
        // update the message with a label
        self.phoneMessageLabel.setText("\(message)")
    }
    
    
    // MARK: Outlets
    // ----------
    //outlet for the table
    @IBOutlet var tableViewThing: WKInterfaceTable!
    
    // outlet for label to hold messages from phone
    @IBOutlet var phoneMessageLabel: WKInterfaceLabel!
    
    
    // MARK: Data source
    var personDataList = [
       "No Games"
    ]

    
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    
    @IBAction func sendDataBtn() {
        
        if WCSession.isSupported() {
            
            let session = WCSession.default
            session.delegate = self
            session.activate()
            
            if WCSession.default.isReachable {
                
                
                let data = [
                    "item":"Tara Baap ne k j"
                ]
                
                
                session.sendMessage(data, replyHandler: {(_ replyMessage: [String: Any]) -> Void in
                    
                    print("ReplyHandler called = \(replyMessage)")
                    WKInterfaceDevice.current().play(WKHapticType.notification)
                },
                                    errorHandler: {(_ error: Error) -> Void in
                                        
                                        print("Error = \(error.localizedDescription)")
                })
            }
        }
        
    }
    
    
    
    
    
    
    
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
        
        let URL = "https://fifaassignment.firebaseio.com/Staduim.json"
        let URLfnl = "https://fifaassignment.firebaseio.com/Finals.json"
        let URLqtr = "https://fifaassignment.firebaseio.com/Quarterfinal.json"
        let URLsemi = "https://fifaassignment.firebaseio.com/Semifinal.json"
        let URLtp = "https://fifaassignment.firebaseio.com/Thirdplace.json"
        
        Alamofire.request(URL).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let apiData = response.result.value
            if (apiData == nil) {
                print("Error when getting API data")
                return
            }
            
        }
        
        Alamofire.request(URLfnl).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let FinalsData = response.result.value
            if (FinalsData == nil) {
                print("Error when getting API data")
                return
            }
            // -- if no errors, then keep going
            //print(apiData)
            
            // 2a. Convert the response to a JSON object
            var jsonResponseFnl = JSON(FinalsData!)
            
            for (name,value) in (jsonResponseFnl){
                
                let team = value["Team"].stringValue
                
               // let type = value["Type"].stringValue

                
                self.personDataList.append(team)
                print(self.personDataList)
                
                
            }
            
            
        }
        
        
        Alamofire.request(URLqtr).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let QtrData = response.result.value
            if (QtrData == nil) {
                print("Error when getting API data")
                return
            }
            // -- if no errors, then keep going
            //print(apiData)
            
            // 2a. Convert the response to a JSON object
            var jsonResponseqtr = JSON(QtrData!)
            
            print(jsonResponseqtr)
            
            for (name,value) in (jsonResponseqtr){
                
                let team = value["Team"].stringValue
                
                self.personDataList.append(team)
                print(self.personDataList)
                
                
            }
            
        }
        
        Alamofire.request(URLsemi).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let semiData = response.result.value
            if (semiData == nil) {
                print("Error when getting API data")
                return
            }
            // -- if no errors, then keep going
            //print(apiData)
            
            // 2a. Convert the response to a JSON object
            var jsonResponseSemi = JSON(semiData!)
            
            print(jsonResponseSemi)
            
            
            for (name,value) in (jsonResponseSemi){
                
                 let team = value["Team"].stringValue
                self.personDataList.append(team)
                print(self.personDataList)
                
                
            }
            
        }
        
        Alamofire.request(URLtp).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let tpData = response.result.value
            if (tpData == nil) {
                print("Error when getting API data")
                return
            }
            // -- if no errors, then keep going
            //print(apiData)
            
            // 2a. Convert the response to a JSON object
            var jsonResponsetp = JSON(tpData!)
            
            print(jsonResponsetp)
            
            
            for (name,value) in (jsonResponsetp){
                
                let team = value["Team"].stringValue
                
                self.personDataList.append(team)
                print(self.personDataList)
                
                
            }
            
            
        }
        
        
        
        
        
        
        
        
        
        // check for wcsession
        if (WCSession.isSupported()) {
            print("WATCH: WCSession is supported!")
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
        else {
            print("WATCH: Does not support WCSession, sorry!")
        }
        
        
        // 1. Tell watch how many rows you want
        self.tableViewThing.setNumberOfRows(
            self.personDataList.count, withRowType:"myRow"
        )
        
        // 2. Tell watch what data goes in each row
        for (index, data) in self.personDataList.enumerated() {
            
            let row = self.tableViewThing.rowController(at: index) as! RowController
            row.outputLabel.setText(data)
            
            
            
        }
    
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
