//
//  InterfaceController.swift
//  APIDemo WatchKit Extension
//
//  Created by Parrot on 2019-03-03.
//  Copyright © 2019 Parrot. All rights reserved.
//

import WatchKit
import Foundation
import Alamofire
import SwiftyJSON
import WatchConnectivity

class InterfaceController: WKInterfaceController, WCSessionDelegate {
    
    
    // MARK: Data source
    // MARK: Data source
    var personDataList:[String] = []
    
    var GameList: [String] = []
    
    
    
    @IBOutlet var tableViewThing: WKInterfaceTable!
    
    // outlet for label to hold messages from phone
    @IBOutlet var phoneMessageLabel: WKInterfaceLabel!
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    
    // MARK: Outlet
    // ---------------
    
    @IBOutlet var watchOutputLabel: WKInterfaceLabel!
    
    
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        
        // output a debug message to the terminal
        print("WATCH: Got a message!")
        print(message)
        
        self.personDataList = [
            message["message"] as! String
        ]
        
        
        }
    
    
    // MARK: Actions
    @IBAction func getDataPressed() {
        print("Watch button pressed")
        // TODO: Put your API call here
        
        
        
            // 3. Show the data in the user interface
            self.watchOutputLabel.setText("\(self.personDataList)")
    }
    
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
        
        // check for wcsession
        if (WCSession.isSupported()) {
            print("WATCH: WCSession is supported!")
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
        else {
            print("WATCH: Does not support WCSession, sorry!")
        }
        
        
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
